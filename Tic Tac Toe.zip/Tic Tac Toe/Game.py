# similiar code from github
# Tic Tac Toe game

from ast import main


def main_menu():
    # the main function
    introduction = first()
    board = create_grid()
    symbol_1, symbol_2 = symbol()
    full = isFull(board, symbol_1, symbol_2)
    row, column = gameStart()
    # each fuction works on its own

def first():
    # a fuction that produces the rules of this game
    print("Hello!")
    print("Welcome to brie's Tic Tac Toe game!")
    print("\n")
    print("Rules: Player 1 and Player 2,represented by X and O, take turn"
          "marking the spaces in a 3*3 grid"
          "The player who suceeds in placing three of their marks"
          "in horizontal, vertically or diagonal row wins.")
    print("\n")
    print("Press enter to continue")
    print("\n")

def create_grid():
    print("The playboard: ")
    board = [[" "," ",""],
            [" "," "," "],
            [" "," "," "]]  
    return board

def symbol():
    symbol_1 = input("Player 1, are you X or O?")
    if symbol_1 == "X":
       symbol_2 == "O"
       print("Player 2, you are O.")
    else:
        symbol_2 = "X"
        print("Player 2, you are X. ")
    input("Press enter.")
    print("\n")
    return (symbol_1, symbol_2)

def  gameStart(board, symbol_1, symbol_2, count):
    # the start of the game
    if count % 2 == 0:
        player = symbol_1
    elif count % 2 == 1:
        player = symbol_2
        print("Player "+ player + ", your turn. ")
        row = int(input("Pick a row:"
                        "[upper row: enter 0, middle row: enter 1,bottom row: enter 2]:"))
        column = int(input("Pick a column:"
                           "[left column: enter 0, middle column:enter 1, right column enter 2]"))
        
    while(row > 2 or row < 0) or (column > 2 or column < 0):
        outOfBoard(row, column)
        row = int(input("Pick a row[upper row:]"
                        "[enter 0, middle row: enter 1 bottom row: enter 2]"))
        column = int(input("Pick a column:"
                           "[left column: enter 0, middle column: enter 1, right column enter 2]"))
        
    while(board[row][column] == symbol_1) or (board[row][column] == symbol_2):
        filled = illegal(board, symbol_1, symbol_2, row, column)
        row = int(input("Pick a row[upper row:]"
                        "[enter 0 middle row: enter 1, bottom row: enter 2]:"))
        column =int(input("Pick a column:"
                          "[left column: enter 0, middle column: enter 1, right column enter 2]"))
        
    if player == symbol_1:
        board[row][column] = symbol_1

    else:
        board[row][column] = symbol_2
    return

def isFull(board, symbol_1, symbol_2):
    count = 1
    winner = True

    while count < 10 and winner == True:
        gaming = gameStart(board, symbol_1, symbol_2, count)
        pretty = printSecond(board)

    if count == 9:
        print("The board is full. Game over.")
        if winner == True:
            print("It a tie. ")

    winner = isWinner( board, symbol_1, symbol_2,count)
    count += 1
    if winner == False:
        print("Game Over.")

    report(count, winner, symbol_1, symbol_2)

    def outOfBoard(row, column):
        print("Out of boarder.Pick another one. ")

    def printPretty(board):
        rows =len(board)
        cols = len(board)
        print("---+---+---")
        for r in range(rows):
            print(board[r][0], " ", board[r][1], " ", board[r][2])
            print("---+---+---")
        return board

    def isWinner(board, symbol_1, symbol_2, count):
        winner = True
        #Check the rows
        for row in range(0, 3):
            if(board[row][0] == board[row][1] == board[row][2] == symbol_1):
                winner == False
                print("Player" + symbol_1 + ",you won!") 

            elif(board[row][0] == board[row][1] == board[row][2] == symbol_2):
               winner = False
               print("Player "+ symbol_2 + ", you won!")

        for col in range(0,3):
            if(board[0][col] == board[col][1] == board[col][2] == symbol_1):
                winner = False
                print("Player " + symbol_1 + ", you won!")
            elif(board[0][col] == board[col][1] == board[col][2] == symbol_2):
                winner = False
                print("Player " + symbol_2 + ", you won!")

            if board[0][0] == board[1][1] == board[2][2] == symbol_1:
                winner = False
                print("Player "+ symbol_1 + ", you won!")

            elif board[0][0] == board[1][1] == board[2][2] == symbol_2:
                winner = False
                print("Player "+ symbol_1 + ", you won!")

            elif board[0][2] == board[1][1] == board[2][0] == symbol_1:
                winner = False
                print("Player "+ symbol_1 + ", you won!")

            elif board[0][2] == board[1][1] == board[2][0] == symbol_2:
                winner = False
                print("Player "+ symbol_1 + ", you won!")

            return winner
        
        def illegal(board, symbol_1, symbol_2, row, column):
            print("\n")
            input("Press enter to see the game summary.")
            if(winner == False) and (count % 2 ==1):
                print("Winner : Player" + symbol_1 + ".")
            elif(winner == False) and (count % 2 ==0):
                print("Winner : Player "+ symbol_2 + ".")
            else:
                print("There is a tie")

        main()